function dy = Ex2part1e_model(t,y)
%Initialisation

M = 2;
m=0.1;
l=0.5;
g=9.81;
k= -133.11;

r=0;
dy= zeros (6,1);

numc= [1 4.53];
denc = [1 6.53];
[ac bc cc dc]=tf2ss(numc,denc);

e = (r-y(1))*k;
m1 = cc*y(3)+dc*e; 
mt = m1+ y(6);

dy(1) = y(2);           % dy(1) & dy(2) are used to know the response of teta
dy(2) = (M+m)*g/(M*l)*y(1) -(1/M/l)* mt;
dy(3) = ac*y(3)+bc*e;   % State Equation from the controller (e= error of the controller)
dy(4) = y(5);             % dy(4) & dy(5) are used to know the response of the cart "x" on the Ex2 sheet
dy(5) = -m/M*g * y(1) + 1/M* mt;
dy(6) = e;
return;