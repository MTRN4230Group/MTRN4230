options = odeset('RelTol',1e-4,'AbsTol',[1e-5 1e-5 1e-5 1e-5 1e-5 1e-5]);
[t,y] = ode45(@Ex2part1e_model,[0 20],[2 0 0 0 0 0], options);
figure(1);
plot(t,y(:,1),'b');
%axis equal;
title('Angle plot');

figure(2);
plot(t,y(:,4),'b');
title('Displacement of the Cart plot');