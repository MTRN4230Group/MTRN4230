% Plotting the new root locus for the PI controller:
% G(s) = -(s2+5.53s+6.53) / [(s)(s+6.53)(s2-20.601)]; H(s)=1
% G(s)*H(s) = -1/k
numsys=[1 5.53 6.53];
densys=conv([1 6.53 0],[1 0 -20.601]);
rlocus(numsys,densys);
[k,poles]= rlocfind(numsys,densys);

% With the rlocus a k= 133.11 was obtained in order to have a stable time
% response

