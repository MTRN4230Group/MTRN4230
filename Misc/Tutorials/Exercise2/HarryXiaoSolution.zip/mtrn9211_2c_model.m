function dX = mtrn9211_2c_model(t,X)

M=2;
m=0.1;
l=0.5;
g=9.81;

if t<6
    r=1;
else
    r=0;
end


x=X(1:4);
epsilon=X(5);

A=[[0 1 0 0];[2.1*9.81 0 0 0];[0 0 0 1];[-0.1/2*9.81 0 0 0]];
B=[0; -1;0;1/2];
C=[0 0 1 0];
D=[0];

k=[-197.19 -44.2955 -144.56 -59.4830];
k1=-165.994;

u=-k*x+k1*epsilon;
depsilon=-C*x+r;


dx=A*x+B*u;

dX=[dx;depsilon];


return;