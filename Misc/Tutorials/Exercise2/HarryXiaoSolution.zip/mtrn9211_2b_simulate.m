% This file simulates the model described in mtrn9211_first_model.m
options = odeset('RelTol',1e-4,'AbsTol',[1e-5 1e-5 1e-5 1e-5]);

[t,y] = ode45(@mtrn9211_2b_model,[0 10],[2*pi/180 0 0 0], options);


figure(1);
plot(t,y);

legend('angle','ang rate','position','velocity')


