% This file simulates the model described in mtrn9211_first_model.m
options = odeset('RelTol',1e-4,'AbsTol',[1e-5 1e-5 1e-5 1e-5 1e-5]);

[t,y] = ode45(@mtrn9211_2c_model,[0 10],[2*pi/180 0 0 0 0], options);



figure(1);
hold on;
plot(t,y(:,3:4));
plot([0 6 6 10],[1 1 0 0],'r');
legend('position','velocity','setpoint')
grid on;
figure(2);
plot(t,y(:,1:2));
legend('angle','ang rate');
grid on;

