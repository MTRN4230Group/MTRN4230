% This file simulates the model described in mtrn9211_first_model.m
options = odeset('RelTol',1e-4,'AbsTol',[1e-5 1e-5 1e-5 1e-5]);
[t,y] = ode45(@mtrn9211_first_model,[0 5],[0 0 0 0], options);
figure(1);
plot(t,y(:,1),'b',t,y(:,4),'g');
title('Speed(b) and Position(g) plot');
%axis equal;
