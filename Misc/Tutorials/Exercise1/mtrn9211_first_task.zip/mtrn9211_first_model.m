function dy = mtrn9211_first_model(t,y)
% Initialisation
B = 40e-9;
J = 1e-3;
L = 4e-3;
R = 2.482;
n = 2;
ke = 0.0662e0;
kt = 0.0662e0;
% State variables
% [x1 x2]
% x1 - Omega the controlled quantity in rad/s.
% x2 - \dot{Omega} acceleration

% controller parameters
kp = 1.1;
kppos = 2.0;
kd = 0.001;
ki = 10;
%-----------------------

dy = zeros(4,1);
% update state variables (refer to eq (3.12) and fill in the state
% equations below
x1 = y(1);
x2 = y(2);
x3 = y(3);
x4 = y(4);

%desired position
setPointPos = 100;

%controller equ. for position
setPoint = kppos*(setPointPos-x4);

%limit for maximum velocity
maxVel = 40;
if setPoint>maxVel
    setPoint=maxVel;
end
v = 12;
if t>0 %for jump on t>3 change it to t>3
    v = kp*(setPoint-x1) + x2*kd + ki*x3; %controller equ for speed
end
dy(1)= x2;
dy(2)= -(L*B+R*J)/(L*J)*x2-(R*B+n*n*ke*kt)/(L*J)*x1+(n*n*kt/L/J)*v;
dy(3)= setPoint-x1;
dy(4)= x1;