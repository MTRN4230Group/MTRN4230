%stimulate model

options = odeset('RelTol',1e-4,'AbsTol',[1e-5 1e-5 1e-5]);
[t,y] = ode45(@mtrn4020_first_model_position, [0 5], [0 0 0], options);
figure(1);
%hold on;
plot(t,y(:,1),'b', t, y(:,3), 'r');
%axis equal
title('position plot');