function dy = mtrn4020_first_model_PID(t,y)
%Initialisation
B = 40e-9;
J = 1e-3;
L = 4e-3;
R = 2.482;
n = 2;
ke = 0.0662e0;
kt = 0.0662e0;
Kp = 1.45;
Kd = 0.05;
ki = 1.45;
%State variables
%[x1 x2]
%x1 - omega, controlled quantity in rad/s, out put
%x2 - omega dot, acceleration

%controlled inputs

%proportional term
error = 350 - y(1);
%derivative of error
de = -y(2);



dy = zeros(3,1);
% state variables equations
x1 = y(1);
x2 = y(2);
x3 = y(3);

% v - Applied voltage v(t)
v = Kp*error + Kd*de  + ki*x3;

dy(1) = x2;
dy(2) = -((L*B + R*J)/(L*J))*x2 - ((R*B + n*n*ke*kt)/(L*J))*x1 + ((n*n*kt)/(L*J))*v;
%integrator
dy(3) = error;

end

